import styles from "./page.module.css";
import Link from "next/link";
export default function Home() {
  return (
    <div className={styles.container}>
      <main className={styles.main}>
        <h2 className={styles.title}>
          Multi-Page Websit Using NEXT.js || Easy Coding Tutorial
        </h2>

        <div className={styles.Grid}>
          <Link href="/" className={styles.Card}>
            <h2>Home &rarr;</h2>
          </Link>{" "}
          <Link href="/About" className={styles.Card}>
            <h2>About &rarr;</h2>
          </Link>{" "}
          <Link href="/Contact" className={styles.Card}>
            <h2>Contact &rarr;</h2>
          </Link>
        </div>
      </main>
    </div>
  );
}
