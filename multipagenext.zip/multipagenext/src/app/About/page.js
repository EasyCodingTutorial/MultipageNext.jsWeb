import styles from "./about.module.css";
import Link from "next/link";
export default function About() {
  return (
    <>
      <div className={styles.Container}>
        <h1 className={styles.Title}>
          <Link href="/">Home &rarr;</Link>
          About Page
        </h1>

        <p className={styles.Descrp}>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. At nesciunt,
          iusto commodi provident labore dolor atque exercitationem similique
          optio tempora aperiam. Id porro at, maiores qui laboriosam sed nostrum
          praesentium. <br />
          <br />
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam,
          iste. Vel aspernatur aliquid perferendis quae alias et accusantium
          nihil! Totam officia eius maxime inventore provident dicta! Mollitia
          doloribus laudantium ratione.
        </p>
      </div>
    </>
  );
}
