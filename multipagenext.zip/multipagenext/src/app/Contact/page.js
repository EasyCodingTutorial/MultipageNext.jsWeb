import styles from "./contact.module.css";
import Link from "next/link";
export default function Contact() {
  return (
    <>
      <div className={styles.Container}>
        <h1 className={styles.Title}>
          <Link href="/">Home &rarr;</Link>
          Contact Page
        </h1>

        <div className={styles.Details}>
          <li className={styles.list}>
            <label className={styles.label}>Name:</label>
            <p className={styles.Value}>Easy Coding</p>
          </li>{" "}
          <li className={styles.list}>
            <label className={styles.label}>Email:</label>
            <p className={styles.Value}>ecoding45@gmail.com</p>
          </li>
        </div>
      </div>
    </>
  );
}
